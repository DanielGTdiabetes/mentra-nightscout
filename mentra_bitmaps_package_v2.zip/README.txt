# Paquete de bitmaps (validos) + loader y demo

## Estructura
- /assets/bitmaps/
  - alert-high-526x100.bmp
  - alert-low-526x100.bmp
  - weather-sun-526x100.bmp
  - weather-cloud-526x100.bmp
  - weather-rain-526x100.bmp
- bitmaps.js   → loader con validación via BitmapUtils
- demo.js      → ejemplo que muestra cada bitmap

## Requisitos
- Node 18+
- `@mentra/sdk` en package.json
- Variables de entorno: PACKAGE_NAME y (opcional) PORT

## Uso rápido
1) Copia todo en tu repo.
2) `npm i @mentra/sdk`
3) `node demo.js`
   - Verás: HIGH → LOW → sol → nube → lluvia → clearView()
4) En tu app, importa el loader:
   ```js
   const { loadBitmaps } = require("./bitmaps");
   const icons = await loadBitmaps();
   await session.layouts.showBitmapView(icons.high, { durationMs: 5000 });
   ```

## Notas
- Todos los BMP son monocromo (1-bit), 526x100, sin compresión.
- Usa bitmaps puntuales (alertas). Mantén HUD principal en texto para ahorrar batería.